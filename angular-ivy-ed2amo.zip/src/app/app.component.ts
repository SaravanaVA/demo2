import { Component, VERSION } from "@angular/core";

import { FormBuilder } from "@angular/forms";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  constructor(private fb: FormBuilder) {}
  noteForm = this.fb.group({
    addNoteControl: [""]
  });

  public notestList = [];

  addNote() {
   let notes = this.noteForm.value.addNoteControl;

    this.notestList.push(notes);

    console.log('notes list -->', this.notestList);
  }

  deleteNote(index) {
   this.notestList.splice(index,1);
  }
}
